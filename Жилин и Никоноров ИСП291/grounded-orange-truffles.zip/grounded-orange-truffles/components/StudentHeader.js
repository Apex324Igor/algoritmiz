import React from 'react';
import { View, Text, Image, StyleSheet } from 'react-native';

export default function StudentHeader({ fullName, group, specialty, avatarUrl }) {
  return (
    <View style={styles.headerCard}>
      <Image source={{ uri: avatarUrl }} style={styles.avatar} />
      <View style={styles.infoContainer}>
        <Text style={styles.name}>{fullName}</Text>
        <Text style={styles.group}>Группа: {group}</Text>
        <Text style={styles.specialty}>{specialty}</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  headerCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    padding: 16,
    borderRadius: 14,
    marginBottom: 14,
    elevation: 3,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 6,
  },
  avatar: {
    width: 60,
    height: 60,
    borderRadius: 30,
    marginRight: 14,
  },
  infoContainer: {
    flex: 1,
  },
  name: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#1A1A1A',
    marginBottom: 2,
     },
  group: {
    fontSize: 13,
    fontWeight: '600',
    color: '#1E88E5',
    marginBottom: 2,
  },
  specialty: {
    fontSize: 11,
    color: '#666666',
  },
});