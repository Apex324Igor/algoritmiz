import React, { useState } from 'react';
import { View, Text, StyleSheet, SafeAreaView, ScrollView } from 'react-native';
import { initialTasks } from './data/tasksData';
import StudentHeader from './components/StudentHeader';
import StatsSummary from './components/StatsSummary';
import TaskCard from './components/TaskCard';

export default function App() {
  const [tasks, setTasks] = useState(initialTasks);

  const handleToggleTask = (taskId) => {
    setTasks(prevTasks =>
      prevTasks.map(task =>
        task.id === taskId ? { ...task, isCompleted: !task.isCompleted } : task
      )
    );
  };

  const completedCount = tasks.filter(t => t.isCompleted).length;

  return (
    <SafeAreaView style={styles.safeArea}>
      <ScrollView contentContainerStyle={styles.container}>
        <StudentHeader
          fullName="Иванов Иван Иванович"
          group="ИСП-21"
          specialty="09.02.07 Информационные системы и программирование"
          avatarUrl="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTzr9XqBam7n7UrFzRkZrxHyZJtdMNX79VHblw_gYCCTCt2XlIbAsC8XCU&s=10"
        />

        <StatsSummary total={tasks.length} completed={completedCount} />

        <Text style={styles.sectionTitle}>Практические работы по модулю:</Text>

        {tasks.map(task => (
          <TaskCard key={task.id} task={task} onToggle={handleToggleTask} />
        ))}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#F0F2F5',
  },
  container: {
    padding: 14,
  },
  sectionTitle: {
    fontSize: 15,
    fontWeight: 'bold',
    color: '#37474F',
    marginBottom: 10,
    marginLeft: 2,
  },
});