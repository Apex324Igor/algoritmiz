import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';

export default function Navigation({ currentScreen, setScreen }) {
  return (
    <View style={styles.container}>
      <TouchableOpacity
        style={[styles.btn, currentScreen === 'arena' && styles.activeBtn]}
        onPress={() => setScreen('arena')}
      >
        <Text style={[styles.btnText, currentScreen === 'arena' && styles.activeText]}>🌐 Взлом Сети</Text>
      </TouchableOpacity>
      <TouchableOpacity
        style={[styles.btn, currentScreen === 'market' && styles.activeBtn]}
        onPress={() => setScreen('market')}
      >
        <Text style={[styles.btnText, currentScreen === 'market' && styles.activeText]}>🛒 Черный рынок</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flexDirection: 'row', backgroundColor: '#0F172A', padding: 4, borderRadius: 8, marginBottom: 12 },
  btn: { flex: 1, paddingVertical: 8, alignItems: 'center', borderRadius: 6 },
  activeBtn: { backgroundColor: '#0284C7' },
  btnText: { color: '#64748B', fontSize: 12, fontWeight: 'bold' },
  activeText: { color: '#FFFFFF' }
});
