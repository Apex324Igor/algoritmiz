export const initialPlayer = {
  hp: 120,
  maxHp: 120,
  energy: 50,
  maxEnergy: 50,
  credits: 40,
  installedImplants: []
};

export const enemyTemplates = [
  { type: 'Головорез «Мальстрём»', hp: 60, maxHp: 60, dmg: 14, speed: 40, icon: '🤖' },
  { type: 'Корпоративный Дрон-Охотник', hp: 45, maxHp: 45, dmg: 18, speed: 60, icon: '👾' },
  { type: 'Босс: Нетраннер-Ренегат', hp: 140, maxHp: 140, dmg: 22, speed: 50, icon: '🦹' }
];

export const blackMarket = [
  { id: 'imp_1', name: 'Синтетическая кожа', cost: 30, effect: 'maxHp', value: 40, desc: '+40 к максимальному здоровью' },
  { id: 'imp_2', name: 'Био-процессор «Zeta»', cost: 45, effect: 'maxEnergy', value: 25, desc: '+25 к максимальной энергии' },
  { id: 'imp_3', name: 'Медицинский стимулятор', cost: 15, effect: 'heal', value: 60, desc: 'Мгновенное лечение на 60 HP (Одноразовый)' }
];
