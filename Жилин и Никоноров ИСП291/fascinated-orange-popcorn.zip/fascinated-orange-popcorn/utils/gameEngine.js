import { enemyTemplates } from '../data/cyberData';

// Генерация случайного врага с небольшим разбросом характеристик
export const generateRandomEnemy = (level = 1) => {
  const template = enemyTemplates[Math.floor(Math.random() * enemyTemplates.length)];
  const multiplier = 1 + (level - 1) * 0.2; // Усиление с каждым уровнем

  const maxHp = Math.round(template.hp * multiplier);
  return {
    id: `enemy_${Date.now()}`,
    name: template.type,
    hp: maxHp,
    maxHp: maxHp,
    damage: Math.round(template.dmg * multiplier),
    icon: template.icon,
    isHacked: false // Статус дебаффа (ослаблен)
  };
};

export const calculateHit = (baseDamage, isEnemyHacked = false) => {
  const hitChance = Math.random();

  if (hitChance < 0.15 && !isEnemyHacked) {
    return { damage: 0, type: 'MISS' }; // Промах с шансом 15%
  }

  const critChance = Math.random();
  if (critChance > 0.80) {
    return { damage: Math.round(baseDamage * 1.8), type: 'CRIT' }; // Крит 180% урона
  }

  return { damage: baseDamage, type: 'HIT' };
};
