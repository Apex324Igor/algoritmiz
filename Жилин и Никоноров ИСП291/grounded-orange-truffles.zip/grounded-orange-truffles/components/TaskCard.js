import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';

export default function TaskCard({ task, onToggle }) {
  return (
    <View style={[styles.card, task.isCompleted && styles.completedCard]}>
      <View style={styles.headerRow}>
        <Text style={styles.subject}>{task.subject}</Text>
        <Text style={styles.deadline}>{task.deadline}</Text>
      </View>

      <Text style={[styles.title, task.isCompleted && styles.completedTitle]}>
        {task.title}
      </Text>

      <View style={styles.actionRow}>
        <View style={[styles.badge, { backgroundColor: task.isCompleted ? '#E8F5E9' : '#FFF3E0' }]}>
          <Text style={[styles.badgeText, { color: task.isCompleted ? '#2E7D32' : '#EF6C00' }]}>
            {task.isCompleted ? '✓ Сдано' : '○ В процессе'}
          </Text>
        </View>

        <TouchableOpacity 
          style={[styles.button, { backgroundColor: task.isCompleted ? '#757575' : '#8E24AA' }]}
          onPress={() => onToggle(task.id)}
          activeOpacity={0.7}
             >
          <Text style={styles.buttonText}>
            {task.isCompleted ? 'Отменить' : 'Сдать работу'}
          </Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 14,
    marginBottom: 10,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.06,
    shadowRadius: 4,
    borderLeftWidth: 4,
    borderLeftColor: '#EF6C00',
  },
  completedCard: {
    borderLeftColor: '#2E7D32',
    backgroundColor: '#F9FBF9',
  },
  headerRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 6,
  },
  subject: {
    fontSize: 11,
    color: '#757575',
    fontWeight: '600',
    flex: 1,
  },
  deadline: {
    fontSize: 11,
    color: '#9E9E9E',
    marginLeft: 8,
  },
  title: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#212121',
    marginBottom: 10,
  },
  completedTitle: {
    color: '#757575',
    textDecorationLine: 'line-through',
  },
  actionRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  badge: {
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 6,
  },
  badgeText: {
    fontSize: 11,
    fontWeight: 'bold',
  },
   button: {
    paddingHorizontal: 14,
    paddingVertical: 7,
    borderRadius: 8,
  },
  buttonText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: '600',
  },
});