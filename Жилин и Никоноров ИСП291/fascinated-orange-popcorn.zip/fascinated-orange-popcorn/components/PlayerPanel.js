import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

export default function PlayerPanel({ player, currentLevel }) {
  const hpPct = Math.max(0, Math.round((player.hp / player.maxHp) * 100));
  const energyPct = Math.max(0, Math.round((player.energy / player.maxEnergy) * 100));

  return (
    <View style={styles.panel}>
      <View style={styles.row}>
        <Text style={styles.logo}>💠 NETRUNNER_OS v4.1</Text>
        <Text style={styles.level}>Узел Сети: #{currentLevel}</Text>
      </View>

      <View style={styles.barContainer}>
        <Text style={styles.label}>🔋 Синхронизация био-поля: {player.hp}/{player.maxHp} HP</Text>
        <View style={styles.barBg}>
          <View style={[styles.barFill, { width: `${hpPct}%`, backgroundColor: '#10B981' }]} />
        </View>
      </View>

      <View style={styles.barContainer}>
        <Text style={styles.label}>⚡ Вычислительная ОЗУ: {player.energy}/{player.maxEnergy} RAM</Text>
        <View style={styles.barBg}>
          <View style={[styles.barFill, { width: `${energyPct}%`, backgroundColor: '#38BDF8' }]} />
        </View>
      </View>

      <Text style={styles.credits}>💳 Крипто-кредиты: <Text style={styles.goldText}>{player.credits} ¤</Text></Text>
    </View>
  );
}

const styles = StyleSheet.create({
  panel: { backgroundColor: '#020617', padding: 14, borderRadius: 10, borderWidth: 1, borderColor: '#1E293B', marginBottom: 12 },
  row: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 10 },
  logo: { color: '#38BDF8', fontSize: 12, fontWeight: 'bold', fontFamily: 'monospace' },
  level: { color: '#F43F5E', fontSize: 12, fontWeight: 'bold' },
  barContainer: { marginBottom: 8 },
  label: { color: '#94A3B8', fontSize: 11, marginBottom: 3 },
  barBg: { height: 6, backgroundColor: '#1E293B', borderRadius: 3, overflow: 'hidden' },
  barFill: { height: '100%' },
  credits: { color: '#F59E0B', fontSize: 13, fontWeight: 'bold', marginTop: 4 },
  goldText: { color: '#FFFFFF' }
});
