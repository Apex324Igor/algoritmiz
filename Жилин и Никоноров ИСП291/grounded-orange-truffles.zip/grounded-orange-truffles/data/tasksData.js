export const initialTasks = [
  {
    id: '1',
    title: 'Настройка облачной среды Expo Snack',
    subject: 'МДК.01.01 Разработка мобильных приложений',
    deadline: 'Срок: сегодня, 12:00',
    isCompleted: true,
  },
  {
    id: '2',
    title: 'Модульная архитектура компонентов React Native',
    subject: 'МДК.01.01 Разработка мобильных приложений',
    deadline: 'Срок: сегодня, 14:00',
    isCompleted: false,
  },
  {
    id: '3',
    title: 'Управление состоянием списка через useState',
    subject: 'МДК.01.01 Разработка мобильных приложений',
      deadline: 'Срок: сегодня, 16:30',
    isCompleted: false,
  },
  {
    id: '4',
    title: 'Беспроводная отладка приложения в Expo Go',
    subject: 'МДК.01.01 Разработка мобильных приложений',
    deadline: 'Срок: завтра, 10:00',
    isCompleted: false,
  },
];