import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';

export default function AbilityBar({ energy, onAction, hackCooldown }) {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Выберите тактическое действие:</Text>

      <TouchableOpacity style={styles.actionBtn} onPress={() => onAction('laser', 0)}>
        <Text style={styles.btnTitle}>🔫 Залп из Лазерной Винтовки</Text>
        <Text style={styles.btnDesc}>Урон: 15 ед. | Расход: 0 RAM</Text>
      </TouchableOpacity>

      <TouchableOpacity
        style={[styles.actionBtn, styles.hackBtn, (energy < 15 || hackCooldown > 0) && styles.disabledBtn]}
        onPress={() => onAction('hack', 15)}
        disabled={energy < 15 || hackCooldown > 0}
      >
        <Text style={styles.btnTitle}>🧠 Скрипт «Замыкание памяти»</Text>
        <Text style={styles.btnDesc}>
          {hackCooldown > 0 ? `ПЕРЕЗАГРУЗКА (${hackCooldown} х.)` : 'Урон: 30 ед. + Ослабление врага | Расход: 15 RAM'}
        </Text>
      </TouchableOpacity>

      <TouchableOpacity
        style={[styles.actionBtn, styles.rechargeBtn, energy >= 50 && styles.disabledBtn]}
        onPress={() => onAction('recharge', 0)}
        disabled={energy >= 50}
      >
        <Text style={styles.btnTitle}>🔋 Перегрузка генератора</Text>
        <Text style={styles.btnDesc}>Восстанавливает +25 RAM | Пропуск своего хода</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { marginBottom: 12 },
  title: { color: '#94A3B8', fontSize: 11, fontWeight: 'bold', textTransform: 'uppercase', marginBottom: 6 },
  actionBtn: { backgroundColor: '#1E293B', padding: 10, borderRadius: 8, marginBottom: 6, borderWidth: 1, borderColor: '#334155' },
  hackBtn: { borderColor: '#A855F7' },
  rechargeBtn: { borderColor: '#0EA5E9' },
  disabledBtn: { opacity: 0.4 },
  btnTitle: { color: '#FFFFFF', fontSize: 13, fontWeight: 'bold' },
  btnDesc: { color: '#94A3B8', fontSize: 10, marginTop: 2 }
});
