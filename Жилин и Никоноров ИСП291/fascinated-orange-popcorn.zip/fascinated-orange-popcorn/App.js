import React, { useState } from 'react';
import { View, Text, StyleSheet, SafeAreaView, ScrollView, TouchableOpacity } from 'react-native';
import { initialPlayer } from './data/cyberData';
import { generateRandomEnemy, calculateHit } from './utils/gameEngine';
import PlayerPanel from './components/PlayerPanel';
import Navigation from './components/Navigation';
import CyberEnemy from './components/CyberEnemy';
import AbilityBar from './components/AbilityBar';

export default function App() {
  const [player, setPlayer] = useState(initialPlayer);
  const [level, setLevel] = useState(1);
  const [enemy, setEnemy] = useState(() => generateRandomEnemy(1));
  const [screen, setScreen] = useState('arena');
  const [hackCooldown, setHackCooldown] = useState(0);
  const [logs, setLogs] = useState(['Соединение установлено. Обнаружен враждебный ИИ!']);

  const addLog = (msg) => setLogs(prev => [msg, ...prev.slice(0, 3)]);

  const handleTurn = (actionType, ramCost) => {
    if (player.hp <= 0) return;

    let nextPlayerHp = player.hp;
    let nextPlayerEnergy = player.energy - ramCost;
    let nextEnemyHp = enemy.hp;
    let nextEnemyIsHacked = enemy.isHacked;
    let nextCooldown = Math.max(0, hackCooldown - 1);

    // 1. ХОД ИГРОКА
    if (actionType === 'laser') {
      const hit = calculateHit(15, enemy.isHacked);
      if (hit.type === 'MISS') addLog('❌ Вы промахнулись лазером!');
      else {
        nextEnemyHp -= hit.damage;
        addLog(`${hit.type === 'CRIT' ? '💥 КРИТ! ' : '⚔️ '}Вы нанесли ${hit.damage} урона винтовкой.`);
      }
    } else if (actionType === 'hack') {
      const hit = calculateHit(30, false);
      nextEnemyHp -= hit.damage;
      nextEnemyIsHacked = true;
      nextCooldown = 3; // Кулдаун на 3 хода
      addLog(`🧠 Скрипт сработал: ${hit.damage} урона. Системы врага замкнуло!`);
    } else if (actionType === 'recharge') {
      nextPlayerEnergy = Math.min(player.maxEnergy, nextPlayerEnergy + 25);
      addLog('🔋 Вы ушли в защиту и накопили +25 единиц RAM.');
    }

    // Проверка смерти врага
    if (nextEnemyHp <= 0) {
      const rewardCredits = enemy.damage * 2;
      setPlayer(prev => ({
        ...prev,
        hp: nextPlayerHp,
        energy: nextPlayerEnergy,
        credits: prev.credits + rewardCredits
      }));
      setHackCooldown(0);
      setLevel(lvl => lvl + 1);
      const nextLvl = level + 1;
      setEnemy(generateRandomEnemy(nextLvl));
      addLog(`🏆 Цель уничтожена! Получено +${rewardCredits} кредитов. Переход на уровень ${nextLvl}.`);
      return;
    }

    // 2. ОТВЕТНЫЙ ХОД ВРАГА (если он выжил и игрок не просто копил энергию без боя)
    if (actionType !== 'recharge') {
      const actualEnemyDmg = nextEnemyIsHacked ? Math.round(enemy.damage / 2) : enemy.damage;
      const enemyHit = calculateHit(actualEnemyDmg, false);

      if (enemyHit.type === 'MISS') {
        addLog('🛡️ Локальные щиты отразили атаку врага (Промах).');
      } else {
        nextPlayerHp -= enemyHit.damage;
        addLog(`💢 Враг контратакует и наносит вам ${enemyHit.damage} урона.`);
      }
    }

    // Обновление состояния системы
    setHackCooldown(nextCooldown);
    setEnemy(prev => ({ ...prev, hp: nextEnemyHp, isHacked: nextEnemyIsHacked }));
    setPlayer(prev => ({ ...prev, hp: Math.max(0, nextPlayerHp), energy: nextPlayerEnergy }));

    if (nextPlayerHp <= 0) {
      addLog('💀 Критический сбой систем. Ваш аватар в сети стерт.');
    }
  };

  // Механика апгрейдов на черном рынке
  const handleBuy = (item) => {
    if (player.credits < item.cost) return;

    setPlayer(prev => {
      const updatedCredits = prev.credits - item.cost;
      if (item.effect === 'maxHp') {
        return { ...prev, credits: updatedCredits, maxHp: prev.maxHp + item.value, hp: prev.hp + item.value, installedImplants: [...prev.installedImplants, item.id] };
      } else if (item.effect === 'maxEnergy') {
        return { ...prev, credits: updatedCredits, maxEnergy: prev.maxEnergy + item.value, energy: prev.energy + item.value, installedImplants: [...prev.installedImplants, item.id] };
      } else if (item.effect === 'heal') {
        return { ...prev, credits: updatedCredits, hp: Math.min(prev.maxHp, prev.hp + item.value) };
      }
      return prev;
    });
    addLog(`🦾 Успешно установлено: ${item.name}.`);
  };

  const handleRestart = () => {
    setPlayer(initialPlayer);
    setLevel(1);
    setEnemy(generateRandomEnemy(1));
    setHackCooldown(0);
    setLogs(['Сеть перезагружена. Новое подключение...']);
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <ScrollView contentContainerStyle={styles.wrapper}>

        <PlayerPanel player={player} currentLevel={level} />
        <Navigation currentScreen={screen} setScreen={setScreen} />

        {player.hp <= 0 ? (
          <View style={styles.deathBlock}>
            <Text style={styles.deathText}>🚨 ВЫБРОС ИЗ СЕТИ: СИСТЕМЫ МЕРТВЫ 🚨</Text>
            <TouchableOpacity style={styles.btnReset} onPress={handleRestart}>
              <Text style={styles.btnResetText}>Переподключиться к серверу</Text>
            </TouchableOpacity>
          </View>
        ) : (
          screen === 'arena' ? (
            <View>
              <CyberEnemy enemy={enemy} />
              <AbilityBar energy={player.energy} onAction={handleTurn} hackCooldown={hackCooldown} />
            </View>
          ) : (
            <CyberShop credits={player.credits} onBuyItem={handleBuy} installed={player.installedImplants} />
          )
        )}

        {/* Терминал логирования */}
        <View style={styles.terminal}>
          <Text style={styles.terminalTitle}>КОНСОЛЬ СЛЕДОВАНИЯ СОБЫТИЙ:</Text>
          {logs.map((l, i) => <Text key={i} style={styles.logLine}>&gt; {l}</Text>)}
        </View>

      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: '#020617' },
  wrapper: { padding: 14 },
  deathBlock: { backgroundColor: '#450a0a', padding: 16, borderRadius: 10, alignItems: 'center', borderWidth: 1, borderColor: '#ef4444', marginBottom: 12 },
  deathText: { color: '#ffffff', fontWeight: 'bold', fontSize: 12, marginBottom: 12, fontFamily: 'monospace' },
  btnReset: { backgroundColor: '#ef4444', paddingHorizontal: 16, paddingVertical: 10, borderRadius: 6 },
  btnResetText: { color: '#ffffff', fontSize: 12, fontWeight: 'bold' },
  terminal: { backgroundColor: '#090d16', padding: 12, borderRadius: 8, borderWidth: 1, borderColor: '#334155', marginTop: 6 },
  terminalTitle: { color: '#475569', fontSize: 10, fontWeight: 'bold', marginBottom: 6 },
  logLine: { color: '#38BDF8', fontSize: 11, fontFamily: 'monospace', marginBottom: 3 }
});
