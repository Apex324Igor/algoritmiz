import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

export default function CyberEnemy({ enemy }) {
  const hpPct = Math.max(0, Math.round((enemy.hp / enemy.maxHp) * 100));

  return (
    <View style={[styles.card, enemy.isHacked && styles.hackedCard]}>
      <View style={styles.header}>
        <Text style={styles.icon}>{enemy.icon}</Text>
        <View>
          <Text style={styles.name}>{enemy.name}</Text>
          <Text style={styles.dmgInfo}>Базовая угроза: ⚔️ {enemy.damage} единиц</Text>
        </View>
      </View>

      <View style={styles.hpBlock}>
        <View style={styles.hpLabelRow}>
          <Text style={styles.hpText}>Целостность ядра ИИ: {enemy.hp}/{enemy.maxHp}</Text>
          {enemy.isHacked && <Text style={styles.debuffBadge}>⚡ СБОЙ ПО</Text>}
        </View>
        <View style={styles.barBg}>
          <View style={[styles.barFill, { width: `${hpPct}%` }]} />
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  card: { backgroundColor: '#0F172A', padding: 14, borderRadius: 12, borderWidth: 1, borderColor: '#F43F5E', marginBottom: 12 },
  hackedCard: { borderColor: '#A855F7', backgroundColor: '#13101C' },
  header: { flexDirection: 'row', alignItems: 'center', marginBottom: 12 },
  icon: { fontSize: 28, marginRight: 10 },
  name: { color: '#F8FAFC', fontSize: 14, fontWeight: 'bold' },
  dmgInfo: { color: '#94A3B8', fontSize: 11, marginTop: 2 },
  hpBlock: { marginTop: 4 },
  hpLabelRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 },
  hpText: { color: '#E2E8F0', fontSize: 11 },
  debuffBadge: { backgroundColor: '#A855F7', color: '#FFF', fontSize: 9, fontWeight: 'bold', paddingHorizontal: 4, paddingVertical: 1, borderRadius: 3 },
  barBg: { height: 6, backgroundColor: '#334155', borderRadius: 3, overflow: 'hidden' },
  barFill: { height: '100%', backgroundColor: '#EF4444' }
});
